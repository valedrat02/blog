---
layout: post
title: Tình yêu khi trưởng thành
img: /assets/uploads/cca663a8c8f793339842866e6c51e6aed590a12a.png
slug: tinh-yeu-khi-truong-thanh
categories: Viết
---
Tình yêu của người trưởng thành thường hướng xa hơn, chứ không còn dừng lại ở mức chỉ cần cảm thấy thích thì được còn tương lai thì tính sau. Có lẽ họ biết họ không còn quá dư thời gian để yêu.

Tình yêu là một khái niệm ta không thể nào định nghĩa một cách chính xác. Ta càng không thể áp đặt tình yêu của ai đó phải giống mình, vì có lẽ tình yêu luôn được hình thành theo cảm nhận của mỗi người. Có lẽ thế, nên mỗi người đều có cách thể hiện tình yêu chẳng giống nhau. Có thể là một tình yêu đầy sa hoa của những cặp đôi sang chảnh, hay tình yêu đầy nồng nhiệt của lứa tuổi vừa chập chững vào yêu, cũng có thể là tình yêu để thể hiện mình đã “lớn” của những cô cậu mới lớn đã thích hơn người. Tất cả đều được họ gọi là tình yêu!

Nhưng riêng những người đã từng trải qua những chông chênh trên đường tình, đã thấy được những giả dối lọc lừa, đã ngán ngẩm cái tình yêu vội vã yêu rồi vội vã rời thì tình yêu giản dị hơn hẳn.Có lẽ khi càng trưởng thành thì tình yêu càng trở nên bình dị, vì đã qua rồi cái thời yêu cuồng sống vội của cái tuổi trẻ ngang bướng và cố chấp.

Khi trưởng thành rồi ta chỉ muốn bên cạnh người ta cảm thấy an toàn và tin tưởng. Ta không còn đưa ra hàng trăm tiêu chí để lựa chọn, ta không còn thích những chàng trai, những cô gái với vẻ ngoài bóng bẩy, mùi nước hoa thơm lừng khắp người hay là một ánh mắt đa tình cùng với một nụ cười tỏa nắng có thể thu hút tất cả những ánh mắt khác hướng về họ. Ta nhận thức được vẻ đẹp bên ngoài không thể làm ta hạnh phúc, khi anh ta/cô ấy biết được lợi thế của mình thì bạn chỉ là một trong sự lựa chọn. Tình yêu của người trưởng thành thường hướng xa hơn, chứ không còn dừng lại ở mức chỉ cần cảm thấy thích thì được còn tương lai thì tính sau. Có lẽ họ biết họ không còn quá dư thời gian để yêu nhiều lần như thế nữa.

Những người bắt đầu trưởng thành họ đánh giá cao những chàng trai/ cô gái có tính cầu tiến hơn là thiên về gia thế. Họ có thể yêu một chàng trai/ cô gái bình thường nhưng người đó có chí vươn lên vì người yêu, anh ấy/ cô ấy không quá sành điệu nhưng anh ấy/cô ấy co thể lo lắng cho bạn hơn cả họ. Vì họ biết được những gì của người ta thì vẫn mãi là của người ta, đừng quá tham vọng những thứ vốn dĩ không thuộc về mình. Chỉ có chàng trai/cô gái đó là của họ, chỉ cần cùng nhau cố gắng, cùng nhau vươn lên thì mọi khó khăn chông gai cũng đều có thể vượt qua tất cả.

Đã qua rồi cái thời yêu cuồng sống vội, giờ chỉ cần một tình yêu giản dị nhưng yên bình. Không cần quá phô trương khi bước cạnh nhau, chỉ cần một cái ôm nhẹ sau lưng, một ánh mắt chân thành khi cảm thấy mệt mỏi. Không cần đưa nhau đi check-in những nhà hàng sang trọng, chỉ cần ngồi bên nhau ăn những món lề đường cũng thấy ấm áp vô cùng, vì ta muốn yêu bằng trái tim chân thành, không hơn thua tính toán, không so hơn tính thiệt với người.

Không cần “up” quá nhiều hình tình tứ trên mạng xã hội, chỉ cần khẽ cười nói em đã có người yêu khi ai đó tán tỉnh trêu đùa. Ta biết tình yêu ta lúc này xúc phát từ trái tim, ta không thích quá ồn ào náo nhiệt, ta chỉ muốn được yên bình lặng lẽ ở cạnh nhau. Không cần thề non hẹn biển với nhau chỉ cần âm thầm giữ gìn mối quan hệ. Vì nhau cố gắng vì nhau thay đổi. Tình yêu trưởng thành giản dị lắm, chỉ cần nghĩ đến nhau khẽ mỉm cười, rồi vội lấy điện thoại nhắn với ai kia một câu sau một ngày dài bận rộn: “Ngủ ngon nhé”!

<div style="text-align: right;"><i>Sưu tầm</i></div>
