---
layout: post
title: 'Đến một lúc, ta chợt nhận ra hạnh phúc từ những điều bình dị'
img: /assets/uploads/se-den-luc.jpg
slug: den-mot-luc
categories: Viết
---
Đến một lúc, chúng ta bỗng thông hiểu tất cả mọi quy luật của đất trời rằng không có gì là trường tồn bất biến, ngược lại chính nhờ sự biến đổi ấy mà chúng ta có những điều mới mẻ tinh khôi.

Đến một lúc, mọi giông tố mịt mùng không che nổi sự bừng sáng của con tim và mọi khổ đau buồn tủi không đánh gục được niềm lạc quan tiềm ẩn trong một tinh thần.
Chúng ta sống quá lâu trong thành kiến và định kiến hẹp hòi cùng với lòng kiêu mạn đứng chen chân trong một ngôi nhà bản ngã; đến một lúc, chúng ta cần phải bước ra khỏi cửa để được ngắm nhìn toàn bộ sự mênh mông và bát ngát của đất trời.

Đến một lúc, ta chợt nhận ra hạnh phúc từ những điều giản dị

Đến một lúc, chúng ta cảm nhận được niềm vui khi tấm lòng rộng mở và trái tim thắp sáng lên niềm tin yêu cuộc sống.

Đến một lúc, chúng ta nhìn lại và cười nhạo vào những trò hề do chính mình tạo ra và chúng ta trở nên lặng lẽ để thấy rõ sự cần thiết của tĩnh tại tâm hồn. Chúng ta chợt nhận thấy quy luật sâu xa của cuộc sống hạnh phúc không chỉ là đón nhận mà còn phải là sự Cho đi.

Đến một lúc, cảm thấy ngập tràn hạnh phúc không phải vì chúng ta vớt lên được cái gì đó từ dòng nước mà chính là quăng bỏ bớt cho dòng nước cuốn trôi.

Đến một lúc, chúng ta hiểu được sự thật của niềm vui không phải là ở đỉnh vinh quang hay ngọn núi ngập hoa vàng mà chính là từng bước chân thảnh thơi và được ngắm hoa cỏ dại trên đường.
Chúng ta chợt nhận ra rằng hạnh phúc không phải ở đâu xa mà chính là sự mãn nguyện trong từng phút giây hiện tại.
Khi đã trải qua bao nhiêu buồn vui thương ghét, bao hy vọng chán chường, bao thành công thất bại.

Đến một lúc chúng ta chợt nhận thấy rằng tất cả mọi sự đời đến và đi, có rồi không dường như chỉ là một tuồng ảo hóa.
Chúng ta cảm thấy mọi lý luận, ngôn từ đều thừa thãi, thay vào đó chỉ cần một nụ cười, một ánh mắt hoặc một tình thương nồng ấm dẫu chỉ là của người khách qua đường cũng đủ làm cho ta ấm lòng và tươi vui hơn trong cuộc sống.

Đến một lúc, chúng ta thấy tuổi trẻ của mình chỉ toàn là ước mơ cùng với nỗ lực vào tương lai hun hút, và đến lúc già đi thì luôn hồi ức tiếc thương một dĩ vãng đã xa rồi. Trong một đời người ngắn ngủi chúng ta đã đánh lỡ đi bao sự sống nhiệm mầu trong thực tại giản đơn.

Đến một lúc, chúng ta hiểu ra rằng duy chỉ có tình thương, chứ không phải có bất cứ thứ gì khác giúp con người thiết lập được trật tự mới và hòa bình cho nhân loại.
Mọi dòng sông đều chảy ra biển cả, mọi con đường chân lý đều hướng về nẻo đạo vô biên và mọi yêu thương chung cuộc đều đạt đến chân phúc.

Đến một lúc, chúng ta cần phải dọn đất trồng hoa trên mảnh vườn của mình còn hơn mỏi mòn chờ đợi ai đó mang hương sắc đến dâng cho.
Tất cả mọi hành động của ta chỉ là những đợt sóng lăn tăn trên mặt biển nhưng trong lòng đại dương sâu thẳm vẫn còn đó sự lặng lẽ bình yên.

Đến một lúc, chúng ta cảm thấy những việc làm thường nhật phải là niềm vui cho sự sống hàng ngày chứ không phải là sự bắt buộc hay là một quán tính khô khan, máy móc của đời mình.
Hiểu ra rằng bản ngã ích kỷ thường khiến mìnhnhìn thấy lỗi lầm, sự xấu xa của người khác hơn là chính bản thân mình. Chúng ta thường che đậy và bảo vệ mình khỏi tổn thương nhưng vô tình điều ấy là tự ôm chất độc và giết chết bản thân mình.

Đến một lúc, chúng ta cảm thấy sự tha thứ, bao dung là món quà tặng vô giá và cần thiết mà con người có thể trao tặng cho nhau không bao giờ cạn.
Khi chúng ta thấy mình tham vọng quá lớn trong khi đời người thật ngắn ngủi, đó là lúc mình hiểu ra hành trang cho lộ trình vạn dặm không phải là những gì có thể nắm bắt bên ngoài mà đó là yếu tố tâm linh bất diệt bên trong.

Đến một lúc, chúng ta hiểu con đường tâm linh thì tuyệt đối đơn độc, không ai có thể đi theo dẫu đó là người thân yêu nhất.
Chúng ta cảm nhận những khoảnh khắc tĩnh lặng nhỏ bé của tâm hồn còn quý giá hơn cả những tài sản được cất chứa chung quanh là lúc chúng ta định lượng được giá trị chân thật của một kiếp người.
Chúng ta hiểu rằng cần phải thánh hóa đời sống hơn là chạy đi tìm thiên đường ở chốn xa xăm.

Đến một lúc, chúng ta cảm thấy không sợ hãi địa ngục hoặc một thế lực tối cao, nhưng bằng trí tuệ tuyệt vời, chúng ta thấy rằng vạn pháp vốn là không và số phận tùy thuộc vào khả năng giác ngộ của chính mình.
Chúng ta cảm thấy nhẹ nhàng, thanh thản trước những mất mát, đau thương vì lòng nước thanh lương có thể cuốn trôi đi bao hệ lụy và có thể đưa chúng ta bến bờ rạng rỡ của ngày mai.Đến một lúc, chúng ta bỗng thông hiểu tất cả mọi quy luật của đất trời rằng không có gì là trường tồn bất biến, ngược lại chính nhờ sự biến đổi ấy mà chúng ta có những điều mới mẻ tinh khôi.

Đến một lúc, mọi giông tố mịt mùng không che nổi sự bừng sáng của con tim và mọi khổ đau buồn tủi không đánh gục được niềm lạc quan tiềm ẩn trong một tinh thần.
Chúng ta sống quá lâu trong thành kiến và định kiến hẹp hòi cùng với lòng kiêu mạn đứng chen chân trong một ngôi nhà bản ngã; đến một lúc, chúng ta cần phải bước ra khỏi cửa để được ngắm nhìn toàn bộ sự mênh mông và bát ngát của đất trời.

Đến một lúc, ta chợt nhận ra hạnh phúc từ những điều giản dị

Đến một lúc, chúng ta cảm nhận được niềm vui khi tấm lòng rộng mở và trái tim thắp sáng lên niềm tin yêu cuộc sống.

Đến một lúc, chúng ta nhìn lại và cười nhạo vào những trò hề do chính mình tạo ra và chúng ta trở nên lặng lẽ để thấy rõ sự cần thiết của tĩnh tại tâm hồn. Chúng ta chợt nhận thấy quy luật sâu xa của cuộc sống hạnh phúc không chỉ là đón nhận mà còn phải là sự Cho đi.

Đến một lúc, cảm thấy ngập tràn hạnh phúc không phải vì chúng ta vớt lên được cái gì đó từ dòng nước mà chính là quăng bỏ bớt cho dòng nước cuốn trôi.

Đến một lúc, chúng ta hiểu được sự thật của niềm vui không phải là ở đỉnh vinh quang hay ngọn núi ngập hoa vàng mà chính là từng bước chân thảnh thơi và được ngắm hoa cỏ dại trên đường.
Chúng ta chợt nhận ra rằng hạnh phúc không phải ở đâu xa mà chính là sự mãn nguyện trong từng phút giây hiện tại.
Khi đã trải qua bao nhiêu buồn vui thương ghét, bao hy vọng chán chường, bao thành công thất bại.

Đến một lúc chúng ta chợt nhận thấy rằng tất cả mọi sự đời đến và đi, có rồi không dường như chỉ là một tuồng ảo hóa.
Chúng ta cảm thấy mọi lý luận, ngôn từ đều thừa thãi, thay vào đó chỉ cần một nụ cười, một ánh mắt hoặc một tình thương nồng ấm dẫu chỉ là của người khách qua đường cũng đủ làm cho ta ấm lòng và tươi vui hơn trong cuộc sống.

Đến một lúc, chúng ta thấy tuổi trẻ của mình chỉ toàn là ước mơ cùng với nỗ lực vào tương lai hun hút, và đến lúc già đi thì luôn hồi ức tiếc thương một dĩ vãng đã xa rồi. Trong một đời người ngắn ngủi chúng ta đã đánh lỡ đi bao sự sống nhiệm mầu trong thực tại giản đơn.

Đến một lúc, chúng ta hiểu ra rằng duy chỉ có tình thương, chứ không phải có bất cứ thứ gì khác giúp con người thiết lập được trật tự mới và hòa bình cho nhân loại.
Mọi dòng sông đều chảy ra biển cả, mọi con đường chân lý đều hướng về nẻo đạo vô biên và mọi yêu thương chung cuộc đều đạt đến chân phúc.

Đến một lúc, chúng ta cần phải dọn đất trồng hoa trên mảnh vườn của mình còn hơn mỏi mòn chờ đợi ai đó mang hương sắc đến dâng cho.
Tất cả mọi hành động của ta chỉ là những đợt sóng lăn tăn trên mặt biển nhưng trong lòng đại dương sâu thẳm vẫn còn đó sự lặng lẽ bình yên.

Đến một lúc, chúng ta cảm thấy những việc làm thường nhật phải là niềm vui cho sự sống hàng ngày chứ không phải là sự bắt buộc hay là một quán tính khô khan, máy móc của đời mình.
Hiểu ra rằng bản ngã ích kỷ thường khiến mìnhnhìn thấy lỗi lầm, sự xấu xa của người khác hơn là chính bản thân mình. Chúng ta thường che đậy và bảo vệ mình khỏi tổn thương nhưng vô tình điều ấy là tự ôm chất độc và giết chết bản thân mình.

Đến một lúc, chúng ta cảm thấy sự tha thứ, bao dung là món quà tặng vô giá và cần thiết mà con người có thể trao tặng cho nhau không bao giờ cạn.
Khi chúng ta thấy mình tham vọng quá lớn trong khi đời người thật ngắn ngủi, đó là lúc mình hiểu ra hành trang cho lộ trình vạn dặm không phải là những gì có thể nắm bắt bên ngoài mà đó là yếu tố tâm linh bất diệt bên trong.

Đến một lúc, chúng ta hiểu con đường tâm linh thì tuyệt đối đơn độc, không ai có thể đi theo dẫu đó là người thân yêu nhất.
Chúng ta cảm nhận những khoảnh khắc tĩnh lặng nhỏ bé của tâm hồn còn quý giá hơn cả những tài sản được cất chứa chung quanh là lúc chúng ta định lượng được giá trị chân thật của một kiếp người.
Chúng ta hiểu rằng cần phải thánh hóa đời sống hơn là chạy đi tìm thiên đường ở chốn xa xăm.

Đến một lúc, chúng ta cảm thấy không sợ hãi địa ngục hoặc một thế lực tối cao, nhưng bằng trí tuệ tuyệt vời, chúng ta thấy rằng vạn pháp vốn là không và số phận tùy thuộc vào khả năng giác ngộ của chính mình.
Chúng ta cảm thấy nhẹ nhàng, thanh thản trước những mất mát, đau thương vì lòng nước thanh lương có thể cuốn trôi đi bao hệ lụy và có thể đưa chúng ta bến bờ rạng rỡ của ngày mai.

<div style="text-align: right;"><i>Thích Thông Nhã</i></div>
