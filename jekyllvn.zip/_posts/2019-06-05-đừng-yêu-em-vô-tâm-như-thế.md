---
layout: post
title: Đừng yêu em vô tâm như thế
img: /assets/uploads/8lbgqre.jpg
categories: Truyện
---
Truyện dành cho những ai đã đã từng vô tâm với người mình yêu, với những trái tim đôi lần lạc lối, với những khối óc đang hoang mang với tình yêu của mình…

Hơn 2 năm không liên lạc, hôm nay biết tin anh trở về nước, tôi không biết lòng mình nên vui hay buồn nữa. Cảm giác của tôi lúc này bồi hồi khó tả vô cùng. Cầm điện thoại đi lại trong phòng không biết có nên gọi cho anh không? Cũng chẳng biết anh đã thay số điện thoại chưa nữa, đã bao lâu thế rồi cơ mà. Tôi cũng mơ hồ không rõ liệu khi tôi gọi tới ở đầu dây bên kia có câu hỏi đầy lạ lẫm “Ai đấy?” không đây? Đầu óc tôi đầy rẫy những hoang mang, bởi tôi sợ nhiều thứ…

Gặp anh rồi liệu tôi có dám đứng trước mặt anh không? Sau những gì tôi đã làm, những gì anh đã chịu tổn thương vì tôi? Tôi quả thực không xứng… tôi lấy tư cách gì mà đòi gặp lại anh? Và anh có lý do gì phải vẫy tay chào hỏi khi nhìn thấy tôi cơ chứ? Giữa hai chúng tôi còn mối quan hệ gì nữa đâu? 1 lâu đài cát vun đắp bao lâu cuối cùng cũng chỉ mất chưa đầy 1 phút để những con sóng tạt đổ, và tình yêu… thì cũng giống như vậy…

Tôi mở chiếc đồng hồ mà tháng trước mình đã mua để tặng anh trong ngày hôm nay. Nhưng rồi tôi vẫn lại không đi, lý do thì nhiều vô kể. Thôi, coi như số mày không tốt, đành để mày ngủ một giấc dài trong chiếc hộp âm u này vậy. Rồi tôi cất nó vào trong ngăn kéo, trong lòng tự hỏi không biết đến khi nào nó mới lại được lôi ra…

Trước kia khi tình yêu của chúng tôi vẫn diễn ra một cách êm đềm và đẹp đẽ. Nhưng 1 người ở Việt Nam, 1 người lại ở tận Lon don. Tôi dù sao cũng chỉ là một cô gái nhỏ bé có trái tim yếu đuối, sợ bị cô đơn, sợ sự xa cách. Một tình yêu không được vun đắp tình cảm thường xuyên liệu có được bền vững. Tôi bắt đầu nghi hoặc tình yêu của mình. Rằng liệu tôi có đợi anh được sau 3 năm không gặp? Rồi ở bên đó tận 3 năm, liệu hình bóng tôi có đủ sức níu kéo chút tình yêu ít ỏi trong trái tim của một người đàn ông??

Không…Tôi không dám chắc… Tình yêu giữa chúng tôi liệu có đủ mãnh liệt để kéo dài 36 tháng? Nếu sau khoảng thời gian đó, chúng tôi chia tay… thì tôi sẽ như thế nào? Khi đó tôi 24 tuổi, liệu còn biết đến tình yêu là gì nữa không? E rằng lúc đó trái tim của tôi đã trở nên chai sạn rồi.

-Hôm nay em thi tốt chứ? Có làm bài được không?

-Cũng tạm- Tôi uể oải trả lời anh qua headphone

-Sao thế? Em làm không tốt à- Giọng anh trở nên lo lắng

-Chắc qua thôi anh ạ! Em nhớ anh quá! Còn bao lâu nữa hả anh?

-35 tháng nữa em yêu ạ! Anh cũng nhớ em lắm!

-Anh nói dối, ở bên ấy mấy cô Tây chẳng như vedette ý chẳng nhẽ anh tệ đến mức không lọt được vào mắt xanh cô nào

-haha, em đùa không thế? Có mà tại anh không màng gì tới mấy cô đó ấy. Có em là đủ, anh không đòi hỏi gì hơn nữa

-Anh chỉ giỏi nịnh, mà anh nói thử xem, anh yêu em chứ?

-Hỏi vớvẩn

-Thì anhcứ trả lời đi

-Tấtnhiên là có, thế mà cũng phải hỏi. Em thật là…

-Vậy anh hứa sẽ đợi em chứ? À không, ý em là anh sẽ chỉ yêu mình em bây giờ và mãi mãi chứ? Chúng mình sẽ kết hôn phải không?

-Đúng thế, em có cần anh nghĩ luôn tên con chúng mình không?

Thế rồi chúng tôi lại bàn bạc chuyện về tương lai. Bàn xem sẽ chụp ảnh cưới ở những đâu, tổ chức hôn lễ chỗ nào, đặt bao nhiêu bàn… Rồi sau khi lấy nhau chúng tôi sẽ phân chia công việc ra sao… nghĩ tới chuyện đó thôi là 2 đứa chúng tôi đã thấy phấn chấn lắm rồi. Những câu chuyện đó giúp chúng tôi thêm tin tưởng vào tình yêu và tương lai của cả 2 hơn. Tôi sẽ cố gắng duy trì tình yêu tốt đẹp ấy.Anh đẹp trai, điều kiện tốt, học vấn lại cao, tôi chẳng còn mơ ước gì cao sang hơn nữa. Anh yêu tôi và tôi yêu anh, trong bối cảnh và thời gian này thì như vậy là đủ. Hãy cứ yêu nhau như mai là ngày tận thế đi!!!

Nhưng tình yêu đâu cứ chỉ nói yêu nhau suông thôi là đủ? Tôi nhớ cái cảm giác hạnh phúc thời mới yêu, những cái nhìn âu yếm và những cái ôm thật chặt anh dành chotôi. Khoảng thời gian ấy thật đẹp biết mấy, lãng mạn biết mấy. Tôi cất nó vào trong cuốn nhật ký để có thể tưởng nhớ lại mỗi lần nghĩ về anh. Khi đó tôi như một nàng công chúa đang đắm mình vào trong một rừng hồng thơ mộng.

Tạm gác lại chuyện của quá khứ, tôi gấp cuốn nhất ký của mình lại. Tôi nhớ anh biết mấymà lại chẳng thể làm được gì. Dạo thời gian này anh bận ôn thi, có lẽ phải thức đêm làm bài tập rồi sáng ra lại vùi mình vào trong đống sách vở trên thư viện trường. Có lẽ tôi lúc này trong trái tim anh bé nhỏ như một hạt cát, còn trái tim tôi đang thực sự trống rỗng biết chừng nào…

Tôi là một đứa con gái vô tư và chẳng thể nào nhốt mình trong sự gò bò của cũi lồng tình yêu. Đến con chim bị nhốt lâu trong lồng còn muốn được giải thoát, được bay lên bầu trời cao rộng kia vậy thì lý do gì mà tôi lại không thể tự do khi không có anh bên cạnh? Tôi muốn được gặp gỡ người khác để lấp đầy đi nỗi cô đơn liệu có gì là sai trái? Suy cho cùng họ cũng vẫn chỉ là người thay thế, còn anh mới thực sự là người tôi yêu. Tôi ở bên họ nhưng trái tim tôi có anh, trái tim tôi yêu anh… có lẽ là được, có lẽ là không sao. Biết đâu ở nơi trời Tây xa xôi kia anh cũng đang làm như thế??

Tôi cuốn mình và trong những mối tình vụn vặt không tên. Tôi không cần biết họ có yêutôi không, chỉ cần biết họ làm tôi vui và làm lấp đi khoảng trống trong tim mình.

Bẵng đi một thời gian dài tôi với anh không online chat chit với nhau nữa. Có lẽ giờ đây anh đang tất bật với những đống kiến thức đồ sộ của mình, còn tôi thì bận rộn với những cuộc vui không bến đỗ. Tôi gần như quên đi sự xuất hiện của anh trong cuộc đời mình. Tôi hết nhớ rồi lại trách anh tại sao lại rời bỏ tôi mà đi tới một nơi xa xôi như vậy. Sắp sinh nhật tôi rồi, liệu anh có còn nhớ không? Nhẫn đôi anh mua sinh nhật em năm trước, liệu vẫn còn trên tay anh?

Tôi tháochiếc nhẫn anh trao thả vào ly rượu, nó sủi bọt…

Liệutình yêu của tôi có khi nào tan luôn vào trong ly rượu đó không?

Vẫn biếtrằng tình yêu thì không màng khoảng cách

Nhưng khoảng cách nào có thể giữ vững được tình yêu?

—

Sinh nhật tôi, vẫn như thường lệ anh ta dẫn tôi đi Bar, vẫn nốc rượu say khướt, vẫnnhảy nhót loạn xị cùng tiếng nhạc xập xình. Từ lúc nào mà tôi trở nên sa đọa đến thế này vậy? Lý do gì khiến tôi trở thành một con người khác như bây giờ?? Phải rồi, là anh… Chính anh. Tôi loạng choạng chỉ tay vào anh ta nói

-Tại sao chứ? Yêu đương mà thế này à? Vì ai mà em lại biến ra thế này?

Tôi khóc, lần đầu tiên tôi khóc vì nhớ anh. Ngày này năm trước anh và tôi ở bên nhau,cùng thổi nến, cùng cắt bánh… trên những trang nhật ký chứa đầy những cung bậc cảm xúc ngọt ngào, vậy sao 365 ngày sau nó lại tồi tệ đến thế? Xa anh, tôi quên mất lý tưởng sống của mình. Xa anh, tôi dường như đánh mất hết đi mọi thứ…phải, tất cả mọi thứ.

-Em sao thế? Em say rồi, để anh đưa em về…

Rồi tay tôi quàng lên vai anh ta, bước những bước đi vụng về, chệnh choạng, con tim lạnh ngắt vì băng giá. Rốt cuộc, tôi vẫn không quên được anh. Rốt cuộc, tôi vẫn không thể ngừng yêu anh. Và rốt cuộc với tôi, anh vẫn là tất cả. Người đang dìu tôi đi đâu có chút ý nghĩa và vị trí gì trong trái tim tôi chứ? Chỉ là một kẻ thay thế không hơn. Tôi đúng là 1 con đàn bà lả lơi và mất dạy… Tôi cứ tự sỉ vả bản thân mình suốt quãng đường về nhà. Nếu ở bên kia anh biết tôi thế này có lẽ anh thất vọng lắm, liệu điều đó có khiến anh ngừng yêu tôi không?

Về tới cửa nhà, trước mặt tôi là gương mặt lạnh ngắt của anh cùng một bó hoa hồng đỏ thắm. Tôi giật mình tỉnh lại quên rằng trước đó mình đã từng mê man trong cơn say. Tôi lúng túng không biết phải giải thích với anh ra sao với cảnh tượng bây giờ. Anh lạnh lùng quay lưng còn tôi quay ra cố gắng cầu xin anh dừng lại

-Anh nghe em giải thích đã…

Anh im lặng 1 hồi nhưng rồi lại bước đi- đó là 1 điều đáng sợ vô cùng. Tôi như một cơn gió mỏng manh đang cố gắng níu giữ một dám mây đang chứa đầy tức giận. Nhưng một chút hy vọng cũng không hề có. Anh vĩnh viễn biến mất trong màn đêm hôm đó – vào ngày sinh nhật tôi. Anh đi như chưa bao giờ xuất hiện trong cuộc đời tôi vậy.

Người tanói hạnh phúc nhất là trong ngày sinh nhật của mình có người yêu mình bên cạnh,còn tôi lại là 1 kẻ đau khổ nhất trên đời.

Tôi liệu còn mặt mũi nào để nói chuyện với anh không? Anh đã ngồi máy bay nửa ngày chỉ muốn dành cho tôi 1 món quà sinh nhật bất ngờ. Còn tôi, buông lơi bên 1 người đàn ông khác trước mặt anh. Tôi như một con mèo ăn vụng bị chủ nhân bắt gặp để rồi không bao giờ dám ngước mặt lên đối diện với chủ nhân

Tôi 22 tuổi, vẫn đủ trẻ để đón chờ những cái sinh nhật của tuổi 23,24. Nhưng tôi lại không dám. Tôi sợ, sợ mỗi năm sinh nhật của mình sẽ lại nhớ tới lỗi lầm của cái tuổi 22. Tôi sợ khi phải nhớ lại những giọt nước mắt đau tận cùng từ trái tim mình trong màn đêm cô độc hôm ấy, sợ ánh mắt giận dữ và thất vọng của anh, sợ cả những bước chân dứt khoát của anh bước ra khỏi cuộc đời tôi nữa. Và tôi sợ ngay cả chính bản thân mình nữa. Tôi ghê rợn, tự thấy cắn rứt với những bước đi lầm lỡ của mình.

2 lần sinh nhật tiếp theo sau đó tôi chỉ ở nhà, xem ti vi xong rồi tắt đèn đi ngủ,không dám đi đâu. Có khi nào đau khổ quá tôi lại ngã vào vòng tay của 1 gã trai lạ nào đó và tưởng tượng đó là anh không? Tôi sợ bản thân mình sẽ không kiềm chế được nỗi nhớ nhung về anh. Vì thế tôi chỉ ngoan ngoãn cất mình trong 4 bức tường. Trên đầu giường tôi vẫn đẻ cuốn nhật ký, thay vì những cảm xúc nồng nàn về tình yêu tôi viết trước kia, giờ nó chỉ còn là những con số đếm ngày anh và tôi chính thức không còn là gì của nhau nữa.

789 ngày- đủ dài để tôi có thể quên đi 1 cuộc tình cũ, nhưng tôi lại không thể quên, chính xác hơn là tôi không dám quên. Bởi trước kia tôi không dám nghĩ rằng mình lại có thể yêu anh nhiều đến thế.

Hôm nay anh trở về nước, tôi lại nhốt mình ở nhà, không dám đi đâu. Có lẽ anh còn nhiều người đáng để gặp hơn tôi. Mà cũng có khi anh đã quên tôi rồi.

Đã lâu rồi tôi không về nhà thăm ông bà và bố mẹ rồi. Cả nhà tôi đều sống ở khu phố cổ tấp nập người qua lại, có muốn được về nhà cũng thật khó khăn, hơn nữa hôm nay lại là chủ nhật.

-Uiii!!!!!!!!!!!!

Tôi giật mình bóp phanh,chiếc xe hư đốn của tôi vừa va phải làm người ta bị ngã. Tôi vội vã xuống xe đỡ anh ta đứng dậy nhưng không ngờ, người tôi va phải lại là anh…Quả nhiên, trái đất hình tròn.

-Sao anh lại ở đây?- Không khỏi bất ngờ tôi thốt lên hỏi

-À… lâu lắm rồi mới về nên anh đi lòng vòng phố cổ tham quan thôi. Hình như cũng không có gì thay đổi mấy em nhỉ?

-Vâng,phố cổ mà!- Mắt tôi đỏ lên khi nhìn anh và nghe anh nói, anh có biết rằng tôinhớ anh lắm không?

-Em saothế?

-Không,em không sau đâu mà- Tôi lấy tay dụi mắt

-Lâu không đi nên anh cũng quên mất đường rồi, từ nãy tới giờ đều đi lòng vòng quanh khu này. Có lẽ lát nữa phải đi mua bản đồ cũng nên

-Em có thể đưa anh đi được mà!

-Thật không?

-Vâng!Em với anh! Sẽ cùng đi tham quan 36 phố phường

Tôi ngồi lên xe quay sang anh nháy mắt

-Anh mau lên đi, em sẽ giúp anh nhớ lại đường nước mình

Anh có vẻ ngượng ngùng nhưng rồi cũng ngồi lên xe. Tôi mỉm cười. Trước kia, chỉ anh lái xe đưa tôi đi lòng vòng Hà Nội, còn tôi ngồi sát phía sau, tay nhét vào túi áo anh bi ba bi bô. Còn giờ, tôi lái xe, anh ngồi phía sau, cách tôi một khoảng trống. Chúng tôi im lặng như khoảng trống trên yên xe. Đôi lúc anh hỏi tôi trả lời, còn tôi thì không dám hỏi, tôi nghĩ mình không đủ tư cách

-Em à-Giọng anh bỗng trầm lại

-Dạ- Tôingoan ngoãn trả lời

-Em cònviết nhật ký không?

-Thời đại này người ta dùg FB, còn em, vẫn lọ mọ làm bạn với bút giấy thôi. Cổ hủ lắm phải không?

-Thế à. May quá, anh có mua một quyển Nhật Ký tặng em, dễ thương lắm, chỉ sợ em không viết nữa thì món quà của anh xem như là vô duyên quá rồi!

Tôi phanh xe đột ngột quay lại hỏi anh:

-Anh mua quà cho em sao?

Anh gật đầu, nhéo má tôi cười

-Sao phải bất ngờ thế?

Cảm giác này sao mà thân quen, gần gũi thế… Tôi nhận món quà từ tay anh, nước mắt như chực rơi, miệng mấp máy nói lời cảm ơn liền bị anh mắng:

-Mứi thế này mà đã xúc động phát khóc rồi, em đúng là trẻ con.

Tối hôm đó, khi trở về nhà, tôi vội vã mở cuốn Nhật ký mà anh tặng. Tôi bất ngờ khi nhìn thấy những hàng chữ nắn nót mà anh viết ở ngay trang đầu tiên:

Em yêu,

Anh xin lỗi, xin lỗi vì đã vô tâm với em như thế. Vô tâm với tình yêu mà em đã dành cho anh. Lẽ ra anh không nên ích kỷ, chỉ biết cho bản thân mình mà quên mất rằng lẽ ra anh cũng cần phải quan tâm tới em, tới tình yêu và tương lai của chúng mình nữa. Anh chỉ biết yêu em một cách vô tâm mà không thể làm được gì như những người đàn ông khác làm cho người mình yêu. Có lẽ em giận anh lắm, nhưng anh còn giận bản thân mình hơn rất nhiều. Giá như anh quan tâm em hơn chút nữa, hiểu cho em hơn chút nữa thì có lẽ tình yêu của chúng mình vẫn đẹp như lúc mới yêu em nhỉ? Anh bỏ đi, không phải vì thất vọng về em mà là thất vọng về chính bản thân mình. Ngay cả người mình yêu cũng không biết cách gìn giữ thì có thể làm được gì? Anh chẳng bao giờ thích những câu chuyện ướt át mà em viết cả. Nhưng sao ấy nhỉ, hôm nay anh lại bắt chước em, viết ra những suy nghĩ lộn xộn, lủn củn trong đầu mình. Có lẽ là bị lây 1 chút từ em rồi đấy! Hy vọng rằng đọc xong em sẽ không cười anh sến súa mà hãy nhận lời xin lỗi chân thành này của anh nhé! Số điện thoại của anh chưa đổi, đọc xong nhắn tin lại cho anh nhé! Anh đợi tin nhắn của em đấy! Yêu em J

Những giọt lệ rơi vô tình làm ướt đẫm trang giấy.Tôi lấy tay quệt đi 2 hàng nước mắt sợ nếu biết anh sẽ lại trách trái tim tôi ủy mị, yếu mềm. Tôi cầm điện thoại, bấm số của anh nhắn “Em cũng yêu anh, yêu anh nhiều lắm!”

**Cre**: Sưu tầm
