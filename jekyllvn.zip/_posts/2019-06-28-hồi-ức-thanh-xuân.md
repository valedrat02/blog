---
layout: post
title: Hồi ức thanh xuân - Crush của tôi
img: /assets/uploads/hvgaar.jpg
slug: hoi-uc-thanh-xuan
categories: Truyện
---
Vẫn quán cũ. Vẫn tách cafe, thân thuộc. Vẫn là cảm giác chờ đợi, một ai đó. Chiều nay, góc phố nhỏ. Cô ấy, một vài đứa bạn, vẫn ngồi đó. Cô ấy vẫn uống cafe. Vẫn cà phê muối năm nào thường hay uống, nhưng năm ấy,... có vị ngọt... Và hôm nay, vẫn trong khoảng thời gian có ai đó đợi chờ, 10 năm đã trôi qua. Hôm nay, hình bóng tôi đã xuất hiện...

- "Ê ku con, mai hóa có bài gì không em?" ~ giọng này là của thằng Khánh chắc
- "Cấp ba mày học nhiều bị ngáo à? Hôm may đúng là thứ 2" \~ nhạc dạo \~ "Thứ 2 là ngày đầu tuần, học hóa cố gắng khôn ngay. Thứ 3, thứ 4, thứ 5 - ngày nào cũng có hóa. Thứ 6 rồi đến thứ 7, ngày nào cũng được đi chơi..."

Ngắt nhạc, tiếng ai đó nói tiếp: "Ai mà chẳng biết, đến nay,đã 10 năm trôi qua rồi, chỉ là đang hồi tưởng lại hồi ức năm ấy, bầu trời HVT - thanh xuân rực rỡ" ~ nói tiếp: "Bây giờ chúng ta, đứa có vợ có chồng, đứa có người yêu, đứa chớm nở mối tình, trưởng thành hết cả, đâu còn hơi tính trả vờ cái tính con nít gianh như hồi đó nữa"

Đã 10 năm rồi đấy! Lớp tôi đang ngồi ở quán cà phê năm ấy, nhưng quán này bây giờ xịn xò hẳn, mở khang trang hơn nhiều. Hồi đó chỉ là vài cái bàn, có thêm chục cái ghế, bên gốc bàng. 9 năm nay họp lớp 42 đứa đủ cả. Á lộn, có 41 thôi vì có 1 thằng đi Pháp du học (hồi ấy nó tính định cư bên đó, không về), thì tính cả cô giáo chủ nhiệm lớp chúng tôi là 42 rồi còn gì.

- "Ei, tụi mày!!! Năm nay thằng Đức về đấy!" ~ tiếng Cừu đây mà
- "Mày quanh năm viết báo lá cải, nay đến đây quảng bá thương hiệu đấy à, bớt xạo lớ dùm cái, 9 năm rồi, thấy bóng dáng nó đâu." ~ Lâm ĐạiK - trùm trường năm ấy
- "Không!! Lần... lần... lần này... là... là... là thật... thật! 100% lun ớ... ớ..."

Con Cừu non năm nào, nay còn giả bộ nói lắp bắp nữa chứ, hài thật đấy...


**Chap1**:

- "Đức, dậy đi, vào tiết rồi, hôm nay kiểm tra đấy! Văn mày nhồi được chữ nào vào đầu chưa mà ngủ?" - Tiếng ai đó vọng bên tai tôi, hình như giọng của Hoàng Fat đây mà, trong đầu nghĩ ~ "Hôm qua vừa nấu bữa lẩu, món chính là sự hùng vĩ, dữ dội của Sông Đà, nấu xong hết cả rồi..."

- "Cô vào, cô vào... Thanh Văn vào" ~ giọng ngọt ngào của con vịt nào vang lên

- "Cả lớp đứng"

5 phút sau, cô chuẩn bị gọi vấn đáp, cô gọi từng thằng lên. Cứ đinh ninh hôm nay mình không bị triệu tập. Tôi bỗng giật mình khi được cô gọi tên: "Đức Lê lên bảng"

ĐM! Mỗi khi cô gọi tên tôi lên, cả lớp lại sặc cười như cửa cống cái bị vỡ. Chắc bởi từ cái tiểu sử. Cái tiểu sử của tôi, đọc lên mà nổi danh, cả trường đều biết, trên Page của lớp tôi, chúng nó rì viêu tôi bằng những đoạn văn lấy đi bao cảm xúc của người đọc. 

À quên giới thiệu với anh em, tôi là Lê Anh Đức, một người Việt Nam, à không Việt Nam tạch rồi, bây giờ quốc gia của tôi gọi là Đông Lào. Người đời thường gọi tôi là Đức Lê, kể cả giáo viên trong trường cũng vậy nữa... 

Trở lại với buổi học văn hôm nay nhé.

- "Em hãy viết một đoạn văn thể hiện ý nghĩa của lời đề từ thứ 2 của tùy bút Người lái đò sông Đà: Chung thủy giai đông tẩu - Đà giang độc bắc lưu"

Ui chết, hôm qua học tủ phần phân tích, nay cô kiểm tra lời đề từ, chưa học gì, nguy thật. Hên là tôi còn nhớ lời. Viết lời lên bảng, tôi bắt đầu chém gió, chắc hẳn tác phẩm bám theo ý nghĩa của lời đề từ.

> Ý lời đề từ rất hay, đó là "mọi dòng sông đều chảy về hướng đông, riêng chỉ có con sông Đà chảy theo hướng bắc". Đây chẳng khác nào tác giả đang khẳng dịnh vẻ đẹp cá tính, độc đáo, khác lạ chỉ có ở sông Đà, bởi sông Mekong, sông Hương hay bất cứ con sông nào đều bắt đầu từ cội nguồn và chảy về hướng đông. Sông Đà như một kẻ phản bội, nó chảy theo hướng bắc rồi góp mình cùng con sông Nhị Hà đổ ra Biển Đông. Cái sự trái lại bất thường, bị coi như kẻ phản bội, cho thấy rằng nó rất hung bạo, dữ tợn và ngang ngược. Sự ngang ngược ấy đã khẳng định nó chính là một võ sĩ hào hùng của thiên nhiên Tây Bắc nơi rừng thiêng nước độc....

Bản thân đang cố gắng tự hào về những dòng chém gió trên bảng, thoáng lát, lại nghe thấy những tiếng gì đó văng vẳng bên tai.

- "Đậu má thằng này, gọi mãi không dậy, cô đang ở cầu thang dãy nhà A rồi" ~ lại là giọng của thằng Hoàng Fat

- "Đức, năm cuối rồi, tự giác đi bạn ei..." ~ Tiến sĩ Điên thôi thúc tôi dậy bằng những đợt sóng cù léc, khiến tôi không thể nhịn cười được.

Dần dần chợt tỉnh, thì ra đó chỉ là một giấc mơ. Tôi dường như đã nghe rõ hẳn tiếng gọi của Hoàng Fat và Tiến sĩ Điên. Tương tự những truyền nhân của xứ Đông Lào, tôi được ví danh như "thần Dương, thánh Nguyễn" vậy (Thần Dương - Hiếu Dương, thánh Nguyễn - Hiếu Nguyễn. 2 truyền nhân lịch sử, du lịch trong mơ; giải thích nôm na ra thì hai người họ giống như Đăm Săn trong Chiến thắng M'tao M'xay á :> ).

Bỗng, có tiếng gào thét, đập cửa, rất lớn, hình như của mẹ:

- "Lê Anh Đức, mày dậy ngay cho tao. Con trai con đứa, hôm qua mày thức đến mấy giờ mà bây giờ chưa chịu dậy vậy hả. Ngủ trương đít lên. Đấy, con nhà người ta sáng đi làm, đêm thức khuya, tần tảo giúp đỡ bố mẹ, còn mày đi làm về là cắm đầu vào máy tính, ngủ đến giờ này đây. Cứ như này, có chó nó yêu mày." ~ nghe có vẻ rất bực. 

Tôi mở con sờ mát phôn lên, xem lại lịch, giờ giấc. 

> 6 giờ 30 phút sáng. Hôm nay, bạn có ...

Đấy, mẹ tôi lúc nào cũng thế, gọi sớm nhất nhì, con gà trên mái chuồng heo còn chưa kịp ngủ cũng bị mẹ tôi đánh thức. 27 tuổi đầu rồi, mà mẹ cứ coi như tôi là mấy đứa con nít không bằng. Bực =))

Ơ!!! Mịa nó, thế đâu là mơ đâu là thực?

Cũng may là tuần này được nghỉ phép, ngày thường mà cứ mơ mộng thế này thì chết không chứ lẹ.

> Hôm nay, bạn có một cuộc hẹn "HỌP QUÁN 12D7 TẠI TRÀ XANH KẸO LẠC LÃO BÀ" lúc 2 giờ chiều. (chuông phôn réo)

À, mẹ tôi làm vậy với tôi không phải là coi tôi là đứa con nít đâu nhé. Bà rất quan tâm đến cả nhà, đặc biệt là tôi. Một điều tôi không hề thích bà là cả ngày dài liền, trong đầu bà, lúc nào cũng chăm chăm kiếm cho mình một đứa con dâu, và luôn miệng bảo tôi đưa bạn gái về nhà.

Có lẽ bí mật thất lạc lâu năm của tôi, vẫn được giấu kín, ngay cả với mẹ tôi. Nói nhỏ nghe này, tôi đã từng thay đổi bản thân vì một đứa con gái...

Câu chuyện của tôi xảy ra cách đây 12 năm:

- "Đi đứng cứ tớn lên, mắt mù hay sao mà đụng vô không xin lỗi hả con heo kia!!!"

~ Trống trường vang lên: TÙNG, TÙNG, TÙNG... !

Tôi chỉ kịp cúi xuống nhặt đồ và xin lỗi vội vàng, không để ý mặt mũi của cô ấy. Chạy vội vào trường, tôi lên lớp, cất balo!


**Chap2**: Lưu bút của Nguyễn Thanh Hoài

- - -

Nguyễn Thanh Hoài là tên cô ấy, người đã thầm theo đuổi tôi, cũng là người làm tôi rung động, cố gắng thay đổi vì cô ấy :).

Tôi nhặt được cuốn lưu bút này 2 năm trước, đó là khoảng thời gian tôi mới về nước, đi thăm cô giáo chủ nhiệm hồi cấp ba. Cô chủ nhiệm bảo tôi cầm hộ cô ấy, khi nào gặp, nhớ trả lại.

- "Này, Đức, cầm giúp Hoài nhé. Nó đã chờ đợi em rất lâu rồi đấy. Nhớ trả cho nó nhé!"

Có lẽ Hoài đã kể cho cô hết câu chuyện, cô đã thấu hiểu câu chuyện tình này đến nhường nào? Câu hỏi của cô có hàm ý gì chăng?

- - -

Tôi đã cố gắng chờ cậu ta từ rất lâu, liệu cậu ta còn nhớ hồi ấy không nhỉ? Đó là lần đầu tiên có một người mà khiến tôi rung động đến vậy.

Không những đẹp troai, mà còn học giỏi,... có vẻ ít nói, trầm... và đó là những nhận xét đầu tiên của tôi về câu ta... Nhưng không biết tự bao giờ, tôi đã đơn phương cậu ta, không phải vì đẹp trai, mà bởi con người cậu ta...

**2.1**: Lần đầu gặp mặt

*12 năm trước*

- "Này, cậu mới chuyển đến đây hả?"

- "Ừm"

Sáng nay, trên đường đến trường, tôi đụng phải cậu ta. Trong giây phút mập mờ, tôi hét toáng lên, mặc dù tôi là người đâm cậu ấy:

- "Đi đứng cứ tớn lên, mắt mù hay sao mà đụng vô không xin lỗi hả con heo kia!!!"

Trông cậu ta có vẻ vội vàng. Tôi ngước mắt nhìn cậu ta, "ui, đẹp troai vĩ". Tôi chưa kịp xin lỗi, cậu ta lượm đồ, nhẹ nhàng:

- "Cậu cho tớ xin lỗi nhé, tớ đang vội."

~ Tôi thầm nghĩ: "người gì đâu, cuteeee thế hông bít"

Cậu ta nhặt chưa hết đã vội bỏ đi sau tiếng trống trường, còn lại một quyển vở, vở hóa thì phải. Tôi mở ra xem thử, có vẻ hơi vô duyên nhỉ?

Họ và tên: Lê Anh Đức

Lớp: 11D7

Trường: PTTH HVT

"Ủa!!! Lớp mình đây mà. Chẳng lẽ cậu ta là học sinh mới chuyển đến???" ~ giây phút suy nghĩ của tôi, bất ngờ, ngạc nhiên.

- "Cô vào các bạn ơi. Lớp mình, hình như hôm nay có học sinh mới."

- "Vào chỗ đi các em, trống 5 phút rồi sao vẫn có bạn đứng bạn ngồi thế kia?" - giọng cô nghe nhẹ nhàng biết mấy

Vương Lâm - lớp phó kỉ luật, hô hào, giọng nghe rõng rạc hẳn:

- "Các bạn đứng. Các bạn chào cô!"

- "Chúng em kính chào cô giáo ạ!"

Cô có dẫn theo một cậu học sinh mới. Là cậu ta, người tôi mà va phải hồi sáng!!!

- "Các em ngồi đi!"

- "Xin được giới thiệu với cả lớp, đây là Đức, học sinh mới của lớp chúng ta. Đức có thể giới thiệu đôi chút về bản thân cho cô và cả lớp cùng nghe không?"

Ùi uôi, cả lớp tôi đứng hình mất chục giây, không chỉ là vóc dáng, hay cậu ta đẹp troai, mà cả giọng nói cũng hay nữa, bây giờ tôi nghe rõ giọng cậu ta hơn là ở cổng trường lúc nãy:

- "Dạ, thưa cô. Chào cả lớp, mình là Lê Anh Đức, học sinh mới chuyển vào lớp. Rất mong cô và cả lớp giúp đỡ mình trong các học kì sắp tới!"

Trời ơi, giọng cuteee!!! Càng bất ngờ hơn, khi tôi được ngồi cạnh Đức:

- "Đức, em tạm thời ngồi cạnh bạn lớp trưởng nhé!"

Về chỗ ngồi, tôi bắt chuyện làm quen:

- "Chào cậu. Tớ là Thanh Hoài, lớp trưởng của lớp 11D7 chúng ta..."

- "Ừm, chào cậu" ~ cười mỉm nhưng có vẻ lạnh lùng

Cậu ta là một kẻ ít nói!

Không giống mấy thằng con trai mặc váy trong lớp, cậu ta rất men lì nhé. Đức thường xuyên tham gia các hoạt động của lớp, của trường. Đặc biệt là cậu ta học rất giỏi, không những là các môn xã hội mà cả các môn tự nhiên nữa...

**2.2**: Cờ rút

Tuy chúng tôi tốt nghiệp cấp ba đã khá lâu rồi, khoảng 8 năm, nhưng tôi vẫn chờ đợi câu trả lời của cậu ta. Cậu ta đã biến mất sau một tuần tôi chủ động tỏ tình trong buổi lễ bế giảng... Khoảng một thời gian ngắn sau đó, cô giáo chủ nhiệm chia sẻ cho tôi biết là cậu ta đã đi Pháp du học.

- "Em!"

- "Dạ, thưa cô!"

- "Em vẫn hy vọng, đợi chờ Đức dù em ấy đã qua Pháp du học chứ?"

- "Cô nói sao? Pháp? Du học?"

Năm cấp ba, vì Đức học khá xa nhà, cũng như tôi và bao học sinh khác trong lớp, Đức ở lại kì túc xá. Những ngày đi học, sáng đến lớp, tôi luôn là người đến lớp đầu tiên, đồng thời, tôi cũng không quên nhắn nhủ với cậu ta vào mỗi buổi sáng. 

Ngày nào cũng vậy, Đức nhận được hộp sữa và một cái bánh sandwick được đặt dưới ngăn bàn, chàng nhấc tờ giấy được gắn kèm theo, đọc, đôi lúc còn cười tủm tỉm:

> Chúc cậu có một buổi sáng tốt lành. Nhớ ăn sáng đầy đủ nhé!

Cuối giờ ca sáng, tôi cũng là người trở về kì túc xá muộn nhất. Ngó lại ngăn bàn của Đức, cậu ta để lại tờ giấy nhắn nhủ của tôi kèm theo vài nét chữ nữa:

> Bánh ngon lắm, cảm ơn cậu nhiều nhé!

Như một đôi bạn thân chẳng thể nào xa rời, tôi và cậu ta đôi lúc cũng đi chơi với nhau, thường xuyên trò chuyện với nhau qua tin nhắn. Đôi lúc là tôi chủ động, nhưng cũng có những lúc là cậu ta.

Những lần dạo làng:

- "Này, ăn đi, đặc sản Thanh Trì đấy!"

- "Oh, cảm ơn Đức nhé!"

Hay lượn chơi đâu đó:

- "Nơi này đẹp quá ha Đức!"

- "Mỗi nơi, mỗi vẻ riêng mà, đối với tớ, cậu luôn đẹp nhất...!"

- "Nè, nè, bớt xạo nha!!!"

- "Giỡn vui chút mà. Hì hì!!!"

...

Cậu ta cũng thi thoảng rủ tôi đi uống cafe, ở quán đối diện cổng trường cấp ba của chúng tôi. Mỗi lần như vậy, cậu ta cũng không quên gọi thêm vài đứa trong lớp đi, cả trai lẫn gái. Nói là gọi vài đứa đi, nhưng là cả lớp đi, vì tụi trong lớp rất thích nghe Đức hát, tôi cũng không ngoại lệ. Nên tôi không dễ gì mà từ chối lời mời của cậu ta.

Lần này không ngoại lệ, tại quán bà lão đối diện cổng trường:

- "Hôm nay, các bạn muốn tôi đàn bài gì nào?"

Cậu ta thích chơi guitar, và giỏi chơi guitar truyền thống. Mỗi lần tiếng đàn cùng với tiếng hát của Đức vang lên, không chỉ lớp tôi mà ngay cả những quán hàng xung quanh hay những cô cậu học sinh đi học trái buổi cũng ngưng lại và chăm chú nghe.

- "Lời thú tội ngọt ngào", "Bí mật của hạnh phúc", "Một vòng trái đất", "Bay giữa ngân hà" ~ Tụi lớp hò reo những bản nhạc từng gây chấn động một thời

Cậu ta cũng không quên hỏi tôi:

- "Hoài, cậu muốn nghe bài gì nào?"

Đây là lần đầu tiên cậu ta khiến tôi lúng túng, bởi cũng là lần đầu tiên cậu ta hỏi tôi, sau bao lần đàn cho cả dọc phố nghe. Tôi ra vẻ lúng túng trước mặt mọi người:

- "Bài... bài..." ~ trời ơi, tôi đỏ mặt nữa chứ

- "Đúng tim đen rồi kìa, trả lời đi, vấp dọ lớp trưởng?" ~ Tụi lớp nhân cơ hội, trêu chọc tôi

- "Bài... bài... Định mệnh ta gặp nhau" ~ tôi cố gắng bình tĩnh trả lời Đức

Đức đỏ mặt. Trời ơi, lúc đỏ mặt mà cậu ta cũng cuteee quá trời quá đất lun ớ!!!

- "Huh? Cậu muốn nghe bài đó à, tớ đàn nhé!" ~ tuy đỏ mặt, nhưng cậu ta vẫn cười mỉm với tôi, có vẻ cậu ta cũng đang...

- "Cậu có thể hát cùng với tớ không, Hoài?"

Tôi bỗng giật mình, đỏ mặt hơn lúc trước, bẽn lẽn trả lời:

- "Ừm, được!"

Sau tiếng trả lời của tôi, cả lớp vỗ tay, à không phải, cả xung quanh nữa chứ.

> Từng đêm anh mơ về em / mơ thấy em trở về / Đến bên anh trong vòng tay ấm áp

- Có đôi khi / anh rời xa / lòng nhớ anh rất nhiều / Nghe tiếng nói anh bên tai / dịu êm

> Định mệnh cho ta gặp nhau / anh với em không rời / Hãy tin anh / hơn một lần em hỡi

<center>...</center>

Tiếng đàn kết thúc, không khí xung quanh, ai ai cũng vỗ tay, khen ngợi Đức và tôi.

- "Anh chị hát hay quá", "Cậu này đàn giỏi, cô bé cũng hát hay ghê" - học sinh, người đi đường reo hò

- "Trời sinh một cặp, hát hay quá Đức ơi Hoài ơi" ~ Tụi lớp khen tấm tắc

Đức càng đỏ mặt hơn, trả tiền nước nhanh gọn, vác guitar về kì túc xá trước

- "Tụi mày đừng nói bậy. Tao xin phép, đi về trước."

Tôi cố gắng rượt theo, nhưng cậu ta về phòng và khóa chặt cửa mất rồi.

Kể từ lần hôm đó, lần cuối cậu ta rủ tôi đi cafe. Tôi càng muốn gần cậu ta bao nhiêu, thì dường như có cái gì đó cản trở tôi, khiến tôi xa cậu ta hơn. Càng xa, tôi càng nhớ. Tôi buồn!

Tôi nhớ cậu ta, nhớ riết. Tôi bỗng tự hỏi "cậu không muốn cùng tớ đi hay sao?", tôi cũng chợt nhận ra, tôi đang đơn phương Lê Anh Đức...

**2.3**: Anh... làm người yêu em nhé

Đôi lúc, cậu ta thầm viết thư cho tôi, và hôm nay cũng vậy, tôi nhận được mẩu thư có nội dung như sau, đọc lên mà thấy buồn.

> Cậu đừng buồn, chuyện hôm guitar đó, cậu quên đi nhé. Tớ mong cậu cũng đừng hiểu lầm giống bọn họ :)

Thi thoảng, cậu ta cũng động viên tôi, hoặc mua sữa bánh cho tôi. Có cảm giác, dường như tôi được gần hơn với cậu ta. Nhưng khoảng cách của tôi và Đức lại càng xa hơn khi chuyện đã xảy ra trong buổi bế giảng lớp 12 và lễ trưởng thành.

"Xa rồi trường cấp ba". Bài hát, người đàn hay, giọng còn hay hơn. Tiếng guitar ngưng, tiếng hát cũng vậy. Mọi người hò reo, vỗ tay răm rắp. Nhưng, đôi chút xúc động, bởi bát hát buồn, biết mấy. Dư âm còn lại,...

> Cành phượng còn yêu dấu, những ngày đầu đến lớp. Thế mà, bây giờ mỗi đứa một nơi...
>
> Tạm biệt nhé my friend, mai xa nhau rồi. Dù đường đời có ra sao, hãy luôn tươi cười...

Tôi sợ rằng, tôi sẽ mất Đức mãi mãi, tôi cũng vui khi nghĩ đến, khi mà cậu ta đồng ý cùng tôi đi hết chặng đường... Nhưng...

- - -

Ở hành lang trước lớp:

- "Đức, tớ có chuyện muốn nói với cậu, thực sự rất muốn..."

- "Huh, chuyện gì?"

- "Anh... làm người yêu em nhé! Nha..."

- "Huh? Cậu vừa nói cái gì thế?"

- "Cậu không nghe thấy à? Tớ bảo là..." - ngập ngùng một lát, tôi nói tiếp - "Em yêu anh, em muốn làm người yêu của anh. Anh... đồng ý nhé!"

- "Này, lớp trưởng, tớ không đùa đâu nhé. Cậu đang đùa tớ đúng không nè, ai lại đi thích một kẻ như tớ chứ. Cậu về phòng đi..." - nói xong, cậu ta đi về phía kì túc xá trường

- "Lê Anh Đức!!! Đứng lại ngay cho em!" ~ tiếng gào của tôi trong vô vọng

Đi một đoạn, cậu ấy bỗng đứng lại. Tôi rượt sau, ôm trầm từ phía sau.

- "Em nói nghiêm túc, em yêu anh, em muốn đi cùng anh, em muốn trái tim của chúng ta không còn sự cách biệt..." ~ đôi bờ mi của tôi bắt đầu đẫm nước mắt

Đức viết vội gì đó vào tờ giấy. Cậu ấy xoay người lại, lấy áo lau nước mắt cho tôi, và đút vội tờ giấy đó vào túi áo tôi, lặng lẽ bỏ đi.

Đoạn vắn tắt nội dung trong giấy, bức thư cuối cùng:

> Thanh Hoài, cảm ơn cậu vì buổi guitar hôm đó. Cảm ơn, cảm ơn tấm lòng của cậu, cảm ơn vì cậu đã thích tớ... Nhưng hiện tại... Sau này, nếu thành công, gặp lại cậu, nhất định tớ sẽ thực hiện ước mơ của cậu... Chờ nhé! Thanh Hoài, anh cũng rất yêu em, tạm biệt...

Đức viết khá dài, tôi không thể nhớ hết được nội dung bức thư đó.

Bữa đó, tôi đọc xong, chạy vội qua phòng Đức, nhưng quản lí kì túc xá nói là cậu ấy đã thu xếp hành lí, đi rồi.

**2.4**: Biết tin của Đức

Đức nhận được xuất học bổng của trường. Cậu ta cũng tham dự kì thi đại học, và trúng tuyển với số điểm gần như tuyệt tối, kết quả này báo cho cô giáo chủ nhiệm của lớp chúng tôi. Tôi tưởng cậu ta sẽ ở lại học đại học cùng tôi, mơ mộng rằng tôi sẽ tiếp tục được nghe những tiếng đàn guitar được chơi bởi một chàng trai thích cafe muối vẫn hay ngồi ở cửa sổ kì túc xá hay ghế đá góc sân trường, nhưng... ngay sau khi thi xong, cậu ta đã bay sang Pháp để du học rồi...

Cô cũng gửi lời của cậu ta cho tôi, có lẽ trước khi đi, cậu ta dặn rất kĩ với cô.

> Cô nói với cậu ấy là cố gắng chờ em nhé. Khi thành công, về em sẽ thực hiện lời hứa của em với cô ấy... Cô nhớ nói với cô ấy giúp em nhé! Em cảm ơn cô ạ!


**Chap3**: Lời cầu hôn

Đọc xong lưu bút của Hoài, cũng là lúc thằng Tú Cừu gọi cho tôi. Giật mình, chợt nhớ ra hôm nay là buổi họp lớp như đã hứa.

- - -

Cứ mộng như là mẹ tôi sẽ không biết chuyện này, ai ngờ trong thời gian tôi đi du học, chuyện tình của 2 đứa bị lộ, cô giáo chủ nhiệm của tôi tiết lộ với mẹ tôi chăng?

Không muốn ảnh hưởng đến quá trình tôi học ở bên Pháp, nên mẹ tôi giữ im lặng, và sau một tháng tôi về nước, mẹ tôi...

- "Đức, mẹ có chuyện muốn nói với con."

- "Dạ, chuyện gì hả mẹ?"

- "Mày với con bé Hoài lớp trưởng yêu nhau bao lâu rồi?"

- "Dạ, sao mẹ biết chuyện này?"

- "Thằng này, mày cứ trả lời cho mẹ nghe xem nào!"

- "Dạ, con cũng không biết nữa..." ~ tôi thầm, cúi mặt

Có lẽ tôi và Hoài đã cùng đơn phương nhau, nhưng không biết rằng bên đối phương cũng có tình ý với mình... Hoặc tôi hoặc Hoài, một trong hai bên nói ra, hoặc sẽ tiếp tục cô đơn như vậy, và thấy đối phương có cuộc tình mới..., hoặc là sẽ đến với nhau và đi cùng nhau **forever**... Nhưng Hoài lại là người chủ động...

Tôi lo sợ rằng, hồi ấy, Hoài đến với tôi sẽ không có tương lai, sẽ chỉ là đôi bàn tay trắng. Tôi cũng lo sợ, khi đi du học, Hoài sẽ cho qua mẩu giấy nhỏ của tôi,... tự chân bước tiếp... theo cuộc hành trình mới... Và cho đến ngày hôm nay, mở cuốn lưu bút của Hoài ra đọc, tôi mới biết được là, Hoài vẫn chờ tôi, ngóng tôi qua từng ngày...

- - -

- "Alo, Đức phải không, đang ở đâu đấy?"

À, một người nữa biết bí mật của tôi là Tú Cừu, thằng bạn thân của tôi. Nó biết tôi về nước đã được hai năm rồi.

- "Ừm, tao đây, mày đang ở quán bà cụ đúng không? Mày rủ thêm mấy đứa nữa ra đầu Tây Trà đi, nhưng không được dẫn thêm Hoài nhé. Tao nhờ chúng mày một việc."

- "Oki con tóaaa!"

Sau đó, Tú dẫn theo Lâm ĐạiK, Sơn già, và một số đứa nữa nhưng không có Hoài, họ đến gặp tôi.

Chúng tôi nghỉ tại một quán nước gần hồ Tây Trà. Chúng tôi vạch ra kế hoạch để tạo ra bất ngờ cho Thanh Hoài trong buổi tối ngày hôm nay. Lâm ĐạiK, Sơn già đi mời đại diện hai bên là bố mẹ tôi, bố mẹ của Hoài, và cả cô giáo chủ nhiệm kính mến của lớp chúng tôi nữa. Một số người khác thì làm việc nhẹ hơn, là chuẩn bị sân khấu, bàn ghế, trang phục. Và đặc biệt là giữ bí mật với Thanh Hoài.

Bối cảnh bữa tiệc tối nay là sân trường, nơi mà có chiếc ghế đá tôi thường hay ngồi cất lên những tiếng guitar truyền thống cho người ấy nghe...

Cô chủ nhiệm dẫn theo Thanh Hoài, nhưng cô ấy đã bị bịt mắt, đến cổng trường, cô giao cô ấy cho tôi. Tôi vẫn giữ tư thế bị mắt cô ấy.

Tiếng đàn guitar năm ấy được cất lên, cũng là bài hát ấy, nhưng không phải tôi hát. Đang bịt mắt người ta thế này, cất giọng lên là lộ hết.

> Định mệnh cho ta gặp nhau anh với em ko rời / Hãy tin anh luôn 1 lần em hỡi / Những đam mê bao lời yêu vào ái ân ước hẹn làm cho ta tin và yêu nhau hơn / Ngày tháng đôi ta gần nhau là tháng năm ta từng yêu

Bản nhạc kết thúc cũng là lúc tôi dẫn cô ấy đến bên ghế đá ngồi xuống.

- "Lê Anh Đức, là anh phải không?" - sau khi không thấy tiếng trả lời, cô ấy hỏi tiếp "Anh về mà không nói cho em biết, còn bày đặt im lặng nữa hả?"

- "Vâng, anh đây, xin lỗi vì đã để em chờ!" - tôi ngoan như con cún, bỏ bịt mắt

Cô ấy bỗng ôm trầm tôi. 

Bản nhạc "Định mệnh ta gặp nhau" một lần nữa được vang lên với sự thể hiện của Lâm ĐạiK (lớp phó kỉ luật của D7) và Thu Trà (cũng là thành viên của D7), họ cũng là một cặp.

- "Lê Anh Đức, anh là đồ hèn, cũng thích người ta mà bỏ đi, không dám ngỏ một lời. Anh biết em nhớ anh lắm không. Hồi đó em còn tưởng anh giận em rồi đi chứ..." ~ Hoài rơm rớm nước mắt, đấm nhẹ vào ngực tôi

- "Anh ở đây rồi!" - tôi nói tiếp - "Có thực sự là em muốn đi cùng anh đến chặng đường còn lại của hai chúng ta không?"

- "Dạ!"

- "Thanh Hoài, đồng ý làm vợ anh chứ?"

- "Dạ, đương nhiên rồi, con heo ngốc nghếch của em!" - cô ấy xiết chặt tôi hơn

Sau đó chúng tôi trao cho nhau những nụ hôn đầu...

- "Chúc mừng hai người nhé!!!" - hai bên gia đình, bạn bè,... reo hò, đồng ý cho hôn sự này

- "Cuối cùng lớp ta cũng được ăn cưới của cặp đôi này rồi!"

<center><b>- HẾT -</b></center>

<div style="text-align: right;"><i><b>Tác giả</b>: Kioku17</i></div>
